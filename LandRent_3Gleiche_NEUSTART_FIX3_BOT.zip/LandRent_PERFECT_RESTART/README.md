# LandRent 3 Gleiche – Clean Restart

This project is a clean Android implementation of the LandRent “3 Gleiche” bot.

## What it does

1. MediaProjection captures the phone screen.
2. The bot finds the white game tiles by connected-component detection.
3. Each tile gets a normalized RGB image descriptor. No fruit list is hard-coded.
4. Similar descriptors are grouped automatically.
5. The bot prefers completing a pair already in the seven-slot tray, otherwise it takes a visible triple/pair.
6. A real Android touch is generated through AccessibilityService `dispatchGesture()`.
7. After every tap the screen is analysed again.

## Build

The included GitHub Actions workflow uses Gradle 8.10.2 and Android Gradle Plugin 8.7.3.

The APK is produced at:

`app/build/outputs/apk/debug/app-debug.apk`

## Phone setup

1. Install the APK.
2. Enable **LandRent 3 Gleiche** under Accessibility.
3. In the app enable screen capture and choose the entire screen.
4. Open the game and leave the 3-Gleiche board visible.
5. Start the bot.

The old bot and any third-party auto-clicker should be disabled during the test so that only this app generates touches.
