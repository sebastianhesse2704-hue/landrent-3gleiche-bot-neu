# Vision validation

The included detector was checked against `gamecrop_reference.png` from the actual game screen.

Observed board: 16 tile faces.
Observed appearance groups: 5 groups with sizes 4, 3, 3, 4 and 2.
The descriptor threshold separates the visible fruit artwork in this reference image without a hard-coded fruit list.
