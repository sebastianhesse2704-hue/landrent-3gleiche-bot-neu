plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.landrent.threeequal"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.landrent.threeequal"
        minSdk = 30
        targetSdk = 35
        versionCode = 100
        versionName = "100.0"
    }
}
