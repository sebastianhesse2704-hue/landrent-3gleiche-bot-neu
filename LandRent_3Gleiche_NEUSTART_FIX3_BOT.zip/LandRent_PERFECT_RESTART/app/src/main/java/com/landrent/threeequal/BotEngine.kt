package com.landrent.threeequal

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Small, deterministic vision solver for the LandRent "3 Gleiche" minigame.
 *
 * No fruit names are hard-coded. The board is found from the white tile faces,
 * then each tile is described by a normalized RGB patch. Identical artwork
 * produces a very small descriptor distance even when the tile is elsewhere
 * on the board.
 */
class BotEngine(private val tap: (Float, Float) -> Boolean) {
    @Volatile var enabled = false

    private var lastActionAt = 0L

    private data class Tile(
        val cx: Float,
        val cy: Float,
        val width: Int,
        val height: Int,
        val descriptor: FloatArray
    )

    private data class Group(val tiles: MutableList<Tile>)

    fun process(frame: Bitmap) {
        if (!enabled) return

        val now = SystemClock.uptimeMillis()
        if (now - lastActionAt < 140L) return
        if (frame.width < 300 || frame.height < 500) return

        val allBoard = detectTiles(frame, 0.30f, 0.90f)
        val board = allBoard.filter { isExposed(it, allBoard) }
        if (board.size < 2) return
        val tray = detectTiles(frame, 0.05f, 0.24f)
        val boardGroups = cluster(board)

        // 1) If two identical tiles are already in the tray, finish them first.
        val finishing = boardGroups
            .filter { it.tiles.isNotEmpty() }
            .map { group ->
                val trayCount = countSimilar(group.tiles[0], tray)
                Triple(group, trayCount, group.tiles.size)
            }
            .filter { it.second >= 2 }
            .maxByOrNull { it.second * 100 + it.third }

        if (finishing != null) {
            clickTiles(finishing.first.tiles.take(1), now)
            return
        }

        // 2) If three identical exposed tiles are visible, take the triple.
        val triple = boardGroups
            .filter { it.tiles.size >= 3 }
            .maxByOrNull { group ->
                val trayCount = countSimilar(group.tiles[0], tray)
                trayCount * 100 + group.tiles.size
            }

        if (triple != null) {
            clickTiles(triple.tiles.take(3), now)
            return
        }

        // 3) Otherwise build the most useful pair, preferring a tray match.
        val pair = boardGroups
            .filter { it.tiles.size >= 2 }
            .maxByOrNull { group ->
                val trayCount = countSimilar(group.tiles[0], tray)
                trayCount * 100 + group.tiles.size
            }

        if (pair != null) {
            val trayCount = countSimilar(pair.tiles[0], tray)
            val needed = if (trayCount == 1) 2 else 1
            clickTiles(pair.tiles.take(needed), now)
            return
        }

        // 4) Last resort: take one tile whose class has the most remaining mates.
        // This avoids filling the seven-slot tray with unrelated symbols.
        val useful = boardGroups
            .filter { it.tiles.isNotEmpty() }
            .maxByOrNull { group ->
                val trayCount = countSimilar(group.tiles[0], tray)
                trayCount * 100 + group.tiles.size
            }
        if (useful != null) clickTiles(useful.tiles.take(1), now)
    }

    private fun clickTiles(tiles: List<Tile>, now: Long) {
        for (tile in tiles) {
            if (tap(tile.cx, tile.cy)) {
                lastActionAt = now
                return
            }
        }
    }


    private fun isExposed(tile: Tile, all: List<Tile>): Boolean {
        for (other in all) {
            if (other === tile) continue
            if (other.cy >= tile.cy) continue
            val horizontalOverlap = abs(other.cx - tile.cx) < (other.width + tile.width) * 0.42f
            val verticalCoversCenter = tile.cy >= other.cy - other.height * 0.42f &&
                tile.cy <= other.cy + other.height * 0.48f
            if (horizontalOverlap && verticalCoversCenter) return false
        }
        return true
    }
    private fun countSimilar(tile: Tile, candidates: List<Tile>): Int =
        candidates.count { distance(tile.descriptor, it.descriptor) < MATCH_THRESHOLD }

    private fun cluster(tiles: List<Tile>): List<Group> {
        val groups = ArrayList<Group>()
        for (tile in tiles) {
            var target: Group? = null
            for (group in groups) {
                if (distance(tile.descriptor, group.tiles[0].descriptor) < MATCH_THRESHOLD) {
                    target = group
                    break
                }
            }
            if (target == null) groups += Group(mutableListOf(tile))
            else target.tiles += tile
        }
        return groups
    }

    /** Find the physical tile faces using connected white-face components. */
    private fun detectTiles(src: Bitmap, topFrac: Float, bottomFrac: Float): List<Tile> {
        val w = src.width
        val h = src.height
        val y0 = (h * topFrac).toInt().coerceAtLeast(0)
        val y1 = (h * bottomFrac).toInt().coerceAtMost(h)
        val sample = (w / 600).coerceIn(2, 4)
        val sw = max(1, w / sample)
        val sh = max(1, (y1 - y0) / sample)

        val mask = BooleanArray(sw * sh)
        for (yy in 0 until sh) {
            val sy = (y0 + yy * sample + sample / 2).coerceIn(0, h - 1)
            for (xx in 0 until sw) {
                val sx = (xx * sample + sample / 2).coerceIn(0, w - 1)
                val c = src.getPixel(sx, sy)
                val r = (c ushr 16) and 255
                val g = (c ushr 8) and 255
                val b = c and 255
                val mx = max(r, max(g, b))
                val mn = min(r, min(g, b))
                mask[yy * sw + xx] = mx >= 172 && mx - mn <= 105
            }
        }

        val seen = BooleanArray(mask.size)
        val queue = IntArray(mask.size)
        val candidates = ArrayList<TileCandidate>()
        val minW = (w * 0.095f / sample).toInt().coerceAtLeast(8)
        val maxW = (w * 0.18f / sample).toInt().coerceAtMost(sw)
        val minH = (w * 0.10f / sample).toInt().coerceAtLeast(9)
        val maxH = (w * 0.20f / sample).toInt().coerceAtMost(sh)
        val minArea = (minW * minH * 0.22f).toInt().coerceAtLeast(35)

        for (start in mask.indices) {
            if (!mask[start] || seen[start]) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            seen[start] = true
            var minX = start % sw
            var maxX = minX
            var minY = start / sw
            var maxY = minY
            var area = 0

            while (head < tail) {
                val p = queue[head++]
                val x = p % sw
                val y = p / sw
                area++
                minX = min(minX, x); maxX = max(maxX, x)
                minY = min(minY, y); maxY = max(maxY, y)

                if (x > 0) tail = visit(p - 1, mask, seen, queue, tail)
                if (x + 1 < sw) tail = visit(p + 1, mask, seen, queue, tail)
                if (y > 0) tail = visit(p - sw, mask, seen, queue, tail)
                if (y + 1 < sh) tail = visit(p + sw, mask, seen, queue, tail)
            }

            val bw = maxX - minX + 1
            val bh = maxY - minY + 1
            if (area >= minArea && bw in minW..maxW && bh in minH..maxH) {
                candidates += TileCandidate(
                    (minX + maxX + 1) * sample / 2f,
                    y0 + (minY + maxY + 1) * sample / 2f,
                    bw * sample,
                    bh * sample,
                    area
                )
            }
        }

        // A tile can produce a second smaller white component when another tile
        // overlaps its rounded corner. Keep the largest component per physical tile.
        return candidates.sortedByDescending { it.area }.fold(ArrayList<Tile>()) { out, c ->
            if (out.none { abs(it.cx - c.cx) < w * 0.11f && abs(it.cy - c.cy) < w * 0.11f }) {
                val hw = (c.width * 0.43f).toInt().coerceAtLeast(12)
                val hh = (c.height * 0.43f).toInt().coerceAtLeast(12)
                out += Tile(c.cx, c.cy, c.width, c.height, descriptor(src, c.cx.toInt(), c.cy.toInt(), hw, hh))
            }
            out
        }
    }

    private data class TileCandidate(val cx: Float, val cy: Float, val width: Int, val height: Int, val area: Int)

    private fun visit(index: Int, mask: BooleanArray, seen: BooleanArray, q: IntArray, tail: Int): Int {
        if (!mask[index] || seen[index]) return tail
        seen[index] = true
        if (tail < q.size) {
            q[tail] = index
            return tail + 1
        }
        return tail
    }

    private fun descriptor(src: Bitmap, cx: Int, cy: Int, halfW: Int, halfH: Int): FloatArray {
        val n = 12
        val out = FloatArray(n * n * 3)
        var k = 0
        val left = (cx - halfW).coerceAtLeast(0)
        val top = (cy - halfH).coerceAtLeast(0)
        val right = (cx + halfW).coerceAtMost(src.width - 1)
        val bottom = (cy + halfH).coerceAtMost(src.height - 1)
        val width = max(1, right - left)
        val height = max(1, bottom - top)
        for (j in 0 until n) {
            val y = (top + ((j + 0.5f) * height / n)).toInt().coerceIn(0, src.height - 1)
            for (i in 0 until n) {
                val x = (left + ((i + 0.5f) * width / n)).toInt().coerceIn(0, src.width - 1)
                val c = src.getPixel(x, y)
                out[k++] = ((c ushr 16) and 255) / 255f
                out[k++] = ((c ushr 8) and 255) / 255f
                out[k++] = (c and 255) / 255f
            }
        }
        return out
    }

    private fun distance(a: FloatArray, b: FloatArray): Float {
        var sum = 0f
        for (i in a.indices) {
            val d = a[i] - b[i]
            sum += d * d
        }
        return sqrt(sum / a.size)
    }

    companion object {
        private const val MATCH_THRESHOLD = 0.205f
    }
}
