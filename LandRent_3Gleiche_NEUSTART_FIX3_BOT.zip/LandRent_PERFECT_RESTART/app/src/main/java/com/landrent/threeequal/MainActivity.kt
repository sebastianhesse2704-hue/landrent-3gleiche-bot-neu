package com.landrent.threeequal

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var botButton: Button
    private val handler = Handler(Looper.getMainLooper())
    private val projectionRequest = 501
    private var captureService: CaptureService? = null
    private var bound = false
    private var botEnabled = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            captureService = (service as CaptureService.LocalBinder).service()
            bound = true
            refreshUi()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            captureService = null
            bound = false
            refreshUi()
        }
    }

    private val statePoller = object : Runnable {
        override fun run() {
            refreshUi()
            handler.postDelayed(this, 500L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        handler.post(statePoller)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 36, 36, 36)
        }

        status = TextView(this).apply {
            text = "Bereit"
            textSize = 19f
            gravity = Gravity.CENTER
        }
        root.addView(status, LinearLayout.LayoutParams(-1, 90))

        root.addView(Button(this).apply {
            text = "BEDIENUNGSHILFE ÖFFNEN"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, buttonParams())

        root.addView(Button(this).apply {
            text = "BILDSCHIRMZUGRIFF AKTIVIEREN"
            setOnClickListener { requestProjection() }
        }, buttonParams())

        root.addView(Button(this).apply {
            text = "BILDSCHIRM TESTEN"
            setOnClickListener {
                status.text = if (CaptureService.running) "Bildschirmzugriff aktiv ✓" else "Bildschirmzugriff nicht aktiv"
            }
        }, buttonParams())

        botButton = Button(this).apply {
            text = "3-GLEICHE-BOT STARTEN"
            isEnabled = false
            setOnClickListener {
                val service = captureService ?: return@setOnClickListener
                botEnabled = !botEnabled
                service.setBotEnabled(botEnabled)
                text = if (botEnabled) "3-GLEICHE-BOT STOPPEN" else "3-GLEICHE-BOT STARTEN"
                status.text = if (botEnabled) "BOT LÄUFT – LandRent öffnen" else "BOT GESTOPPT"
            }
        }
        root.addView(botButton, buttonParams())
        setContentView(root)
    }

    private fun requestProjection() {
        val manager = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequest)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != projectionRequest) return
        if (resultCode != RESULT_OK || data == null) {
            status.text = "Bildschirmfreigabe abgebrochen"
            return
        }

        val intent = Intent(this, CaptureService::class.java).apply {
            putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(CaptureService.EXTRA_DATA, data)
        }
        startForegroundService(intent)
        bindService(Intent(this, CaptureService::class.java), connection, BIND_AUTO_CREATE)
        status.text = "Bildschirmzugriff startet…"
    }

    private fun refreshUi() {
        val touch = BotAccessibilityService.instance != null
        val capture = CaptureService.running
        botButton.isEnabled = touch && capture && bound
        if (!botEnabled) {
            status.text = when {
                !touch && !capture -> "Touch: aus  |  Bildschirm: aus"
                !touch -> "Bildschirm ✓  |  Bedienungshilfe fehlt"
                !capture -> "Touch ✓  |  Bildschirm: aus"
                else -> "Touch ✓  |  Bildschirm ✓"
            }
        }
    }

    private fun buttonParams() = LinearLayout.LayoutParams(-1, 68).apply { bottomMargin = 18 }

    override fun onDestroy() {
        if (bound) {
            try { unbindService(connection) } catch (_: Exception) {}
            bound = false
        }
        handler.removeCallbacks(statePoller)
        super.onDestroy()
    }
}
